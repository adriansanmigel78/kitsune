# http-www.samsung.com-us-aboutsamsung-rss-rssFeedList.do
applications and support
